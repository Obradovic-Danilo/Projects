import socket, random, tkinter, threading, time
from tkinter import *

s = socket.socket()
port = 9998
host = socket.gethostname()
s.bind((host, port))
s.listen(5)


def tajmer(vrednosti, vreme, isporucene):
    lbl = Label(frm1, text=vrednosti)
    lbl.pack()
    lbltime = Label(frm1, text=" - Pica gotova za: ~" + str(vreme) + "min.")
    lbltime.pack()

    while True:

        lbltime.config(text=" - Pica gotova za: ~" + str(vreme) + "min.")

        if vreme == 0:
            lbltime.destroy()
            lbl.destroy()
            COMPLETED = Label(frm2, text=isporucene).pack()
            break
        vreme -= 1
        time.sleep(1)


def povezivanje():


    while True:
        konekcija, adresa = s.accept()
        vrednosti = str(konekcija.recv(1024).decode())
        rndbroj = random.randrange(5, 15)

        isporucene = vrednosti
        poruka = "Vaša pica će biti gotova za ~%d minuta. " % (rndbroj)
        konekcija.send(poruka.encode())

        threading.Thread(target=tajmer, args=(vrednosti, rndbroj, isporucene)).start()


t = threading.Thread(target=povezivanje).start()

root = Tk()
root.title("Server")

frm1 = Frame(root)
frm1.pack()

lblNEISPORUCENE = Label(frm1, text="Neisporučene: ").pack()

frm2 = Frame(root)
frm2.pack()

lblISPORUCENE = Label(frm2, text="Isporučene: ").pack()

root.mainloop()
