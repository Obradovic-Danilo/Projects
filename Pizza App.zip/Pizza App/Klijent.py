import tkinter, socket
from tkinter import *
from tkinter import messagebox


def provera():
    if len(mylist.curselection()) == 0:
        messagebox.showinfo("Greška", "Niste selektovali tip pice!")

    elif len(ADRESA.get()) == 0:
        messagebox.showinfo("Greška", "Niste uneli adresu!")

    elif len(ADRESA.get()) < 5:
        messagebox.showinfo("Greška", "Niste uneli punu adresu!")

    elif len(PHONE.get()) == 0:
        messagebox.showinfo("Greška", "Niste uneli broj telefona!")

    elif any(c.isalpha() for c in PHONE.get()):
        messagebox.showinfo("Greška", "Broj telefona ne sme sadržati slova!")

    elif len(PHONE.get()) < 7:
        messagebox.showinfo("Greska", "Niste uneli ceo broj telefona!")

    else:

        string = ""
        string += mylist.get(ACTIVE)
        if var_rdb.get() == 1:
            string += "(25') -"
        elif var_rdb.get() == 2:
            string += "(32') -"
        elif var_rdb.get() == 3:
            string += "(50') -"

        if kecap.get() == 1:
            string += " Kečap "
        if majonez.get() == 1:
            string += " Majonez "
        if origano.get() == 1:
            string += " Origano "
        if ajvar.get() == 1:
            string += " Ajvar "
        if incuni.get() == 1:
            string += " Inćuni "
        if masline.get() == 1:
            string += " Masline "

        note = NAPOMENA.get()
        if len(NAPOMENA.get()) == 0:
            note = "nema"

        if placanje.get() == 1:
            string += "- Keš - "
        else:
            string += "- Karticom - "
        string += ADRESA.get() + " - " + PHONE.get() + " - " + note

        s = socket.socket()
        port = 9998
        host = socket.gethostname()
        s.connect((host, port))

        s.send(string.encode())
        poruka = s.recv(1024).decode()
        messagebox.showinfo("poruka", poruka)

        string = ""


root = Tk()
root.geometry("400x650")
root.title("Klijent")

kecap = IntVar()
majonez = IntVar()
origano = IntVar()
ajvar = IntVar()
incuni = IntVar()
masline = IntVar()
var_rdb = IntVar()
placanje = IntVar()
ADRESA = StringVar()
PHONE = StringVar()
NAPOMENA = StringVar()

vrstePica = ["Margarita", "Funghi", "Quatro Stagione", "Vegeteriana"]
frm1 = Frame(root)
frm1.pack()
lblNaslov = Label(frm1, text="APP ZA NARUČIVANJE PICE", bg="lightblue", height=10, width=30).pack()
lblVelicina = Label(frm1, text="Veličina pice: ").pack(side=LEFT)
rdb1 = Radiobutton(frm1, text="25'", value=1, variable=var_rdb)
rdb1.select()
rdb1.pack(side=LEFT)
rdb2 = Radiobutton(frm1, text="32'", value=2, variable=var_rdb).pack(side=LEFT)
rdb3 = Radiobutton(frm1, text="50'", value=3, variable=var_rdb).pack(side=LEFT, pady=10)

frm2 = Frame(root)
frm2.pack()
lblVrsta = Label(frm2, text="Vrsta pice:  ").pack(side=LEFT)
mylist = Listbox(frm2, height=4, width=24)
for vrsta in vrstePica:
    mylist.insert(END, vrsta)
mylist.select_set(0)
mylist.pack(pady=10)

frm3 = Frame(root)
frm3.pack()
lblDodaci = Label(frm3, text="Dodaci: ").grid(row=0, column=0, sticky=W)

cb1 = Checkbutton(frm3, text="Kečap", variable=kecap).grid(row=1, column=0, sticky=W)
cb2 = Checkbutton(frm3, text="Majonez", variable=majonez).grid(row=1, column=1, sticky=W)
cb3 = Checkbutton(frm3, text="Ajvar", variable=ajvar).grid(row=1, column=2, sticky=W)
cb4 = Checkbutton(frm3, text="Origano", variable=origano).grid(row=2, column=0, sticky=W)
cb5 = Checkbutton(frm3, text="Inćuni", variable=incuni).grid(row=2, column=1, sticky=W)
cb6 = Checkbutton(frm3, text="Masline", variable=masline).grid(row=2, column=2, sticky=W, pady=10)

frm4 = Frame(root)
frm4.pack()
lblPlacanje = Label(frm4, text="Način placanja: ").grid(row=0, column=0, sticky=W, pady=10)
rdb4 = Radiobutton(frm4, text="Keš", value=1, variable=placanje)
rdb4.select()
rdb4.grid(row=0, column=1, sticky=W)

rdb5 = Radiobutton(frm4, text="Karticom ", value=2, variable=placanje).grid(row=0, column=2, sticky=W)

frm5 = Frame(root)
frm5.pack()
lblAdresa = Label(frm5, text="Adresa: ").grid(row=0, column=0, sticky=W, pady=10)
unosAdrese = Entry(frm5, textvariable=ADRESA).grid(row=0, column=1, sticky=W)
lblTelefon = Label(frm5, text="Broj telefona: ").grid(row=1, column=0, sticky=W, pady=10)
unosTelefona = Entry(frm5, textvariable=PHONE).grid(row=1, column=1, sticky=W)
lblNapomena = Label(frm5, text="Napomena: ").grid(row=2, column=0, sticky=W, pady=10)
unosNapomena = Entry(frm5, textvariable=NAPOMENA).grid(row=2, column=1, sticky=W)

frm6 = Frame(root)
frm6.pack()
btnPosalji = Button(frm6, text="Pošalji", width=15, height=2, command=provera).grid(row=3, column=0, pady=20)

root.mainloop()
