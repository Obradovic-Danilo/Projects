import time

import pygame
from settings import *
from klase import *

pygame.mixer.init()
pygame.mixer.music.load("background_music.wav")
pygame.mixer.music.play(-1)


def pauza():
    pauza = True
    txt = medium_tekst.render("Game paused", False, WHITE)
    while pauza:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pauza = False

            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        SCREEN.blit(txt, (280, 0))
        pygame.display.flip()


def grid():
    for i in range(0, WIDTH, TILESIZE):
        pygame.draw.line(SCREEN, BLACK, (0, i), (WIDTH, i))

    for i in range(0, WIDTH, TILESIZE):
        pygame.draw.line(SCREEN, BLACK, (i, 0), (i, WIDTH))


def music_pause_play():
    global music_1_0

    if music_1_0 == 1:
        pygame.mixer.music.play(-1)
        music_1_0 = 0


    elif music_1_0 == 0:
        pygame.mixer.music.pause()
        music_1_0 = 1


def you_win():
    if len(ALL_POINTS) == 0:
        return True
    else:
        return False


def main_menu():
    meni = True
    SCREEN.fill((135, 206, 235))

    naslov_text = veliki_tekst.render('DPacman', False, BLACK)
    dugme_play_text = mali_tekst.render("Play", False, BLACK)
    dugme_play_pause_music_text = mali_tekst.render("Music On/Off", False, BLACK)
    dugme_quit_text = mali_tekst.render("Quit", False, BLACK)

    while meni:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        pygame.draw.rect(SCREEN, YELLOW, (200, 75, 400, 150))  # -- NASLOV KVADRAT --
        pygame.draw.rect(SCREEN, GREEN, (300, 300, 200, 50))  # -- PLAY KVADRAT --
        pygame.draw.rect(SCREEN, GREEN, (300, 400, 200, 50))  # -- MUSIC KVADRAT --
        pygame.draw.rect(SCREEN, GREEN, (300, 500, 200, 50))  # -- QUIT KVADRAT --
        click = pygame.mouse.get_pressed()
        mouse = pygame.mouse.get_pos()

        if 500 > mouse[0] > 300 and 350 > mouse[1] > 300:
            pygame.draw.rect(SCREEN, RED, (300, 300, 200, 50))
            if click[0] == 1:
                meni = False

        if 500 > mouse[0] > 300 and 450 > mouse[1] > 400:
            pygame.draw.rect(SCREEN, RED, (300, 400, 200, 50))
            if click[0] == 1:
                music_pause_play()

        if 500 > mouse[0] > 300 and 550 > mouse[1] > 500:
            pygame.draw.rect(SCREEN, RED, (300, 500, 200, 50))
            if click[0] == 1:
                pygame.quit()
                quit()

        SCREEN.blit(naslov_text, (242, 100))
        SCREEN.blit(dugme_play_text, (372, 310))
        SCREEN.blit(dugme_play_pause_music_text, (313, 410))
        SCREEN.blit(dugme_quit_text, (372, 510))



        pygame.display.flip()


def main_loop():
    global smer_kretanja_Y, smer_kretanja_X
    pygame.init()

    pygame.display.set_caption("DPacman")
    SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
    igrac = player(12,13)

    ALL_SPRITES.add(igrac)
    # 1 2 2 17 23 2
    for i in range(GRIDHEIGHT):
        for j in range(GRIDWIDTH):
            if MAP[i][j] == 1:
                zid = wall(j, i)
                ALL_SPRITES.add(zid)
                ALL_WALLS.add(zid)
                lista_zidova.append([j, i])


            else:
                point = poen(j, i)
                ALL_SPRITES.add(point)
                ALL_POINTS.add(point)

                if MAP[i][j] not in prethodne_lokacije:
                    lista_bez_zidova.append([j, i])

    no_go = [[1, 2], [0, 2], [1, 17], [0, 17], [23, 2], [24, 2], [23, 17], [24, 17]]
    for e in no_go:
        lista_bez_zidova.remove(e)

    protivnik1 = enemy(20, 5)
    protivnik2 = enemy(4, 5)
    ALL_SPRITES.add(protivnik1)
    ALL_SPRITES.add(protivnik2)
    ENEMY_SPRITES.add(protivnik1)
    ENEMY_SPRITES.add(protivnik2)
    pocetak = True
    while True:

        if pocetak:
            for i in range(3, 0, -1):

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        quit()
                SCREEN.fill(LIGHTGREY)
                ALL_SPRITES.update()
                ALL_SPRITES.draw(SCREEN)
                #grid()
                tekst = medium_tekst.render("%s" % (i), False, WHITE)

                SCREEN.blit(tekst, (389, 0))
                pygame.display.flip()
                time.sleep(1)
            pocetak = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
                break

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_UP:
                    smer_kretanja_Y = -1
                    smer_kretanja_X = 0

                elif event.key == pygame.K_DOWN:
                    smer_kretanja_Y = 1
                    smer_kretanja_X = 0

                elif event.key == pygame.K_LEFT:
                    smer_kretanja_X = -1
                    smer_kretanja_Y = 0

                elif event.key == pygame.K_RIGHT:
                    smer_kretanja_X = 1
                    smer_kretanja_Y = 0

                elif event.key == pygame.K_ESCAPE and not pocetak:
                    pauza()

        if you_win():
            ALL_SPRITES.remove(igrac)
            ALL_SPRITES.remove(protivnik1)
            ALL_SPRITES.remove(protivnik2)
            ENEMY_SPRITES.remove(protivnik2)
            ENEMY_SPRITES.remove(protivnik1)
            for e in ALL_POINTS:
                ALL_POINTS.remove(e)

            del igrac
            del protivnik2
            del protivnik1

            smer_kretanja_X = 0
            smer_kretanja_Y = 0
            gameover_SCREEN("   YOU WIN")

        if igrac.sudar_sa_protivnikom():
            pygame.display.flip()
            ALL_SPRITES.remove(igrac)
            ALL_SPRITES.remove(protivnik1)
            ALL_SPRITES.remove(protivnik2)
            ENEMY_SPRITES.remove(protivnik2)
            ENEMY_SPRITES.remove(protivnik1)
            for e in ALL_POINTS:
                ALL_POINTS.remove(e)
                ALL_SPRITES.remove(e)

            del igrac
            del protivnik2
            del protivnik1

            smer_kretanja_X = 0
            smer_kretanja_Y = 0
            gameover_SCREEN("  YOU LOSE")

        protivnik1.move()
        protivnik2.move()

        igrac.move(smer_kretanja_X, smer_kretanja_Y)

        if igrac.swap_positions():
            ALL_SPRITES.remove(igrac)

        SCREEN.fill(LIGHTGREY)
        ALL_SPRITES.update()
        ALL_SPRITES.draw(SCREEN)
        #grid()
        pygame.display.flip()

        if igrac.sudar_sa_protivnikom():

            ALL_SPRITES.remove(igrac)
            ALL_SPRITES.remove(protivnik1)
            ALL_SPRITES.remove(protivnik2)
            ENEMY_SPRITES.remove(protivnik2)
            ENEMY_SPRITES.remove(protivnik1)
            for e in ALL_POINTS:
                ALL_POINTS.remove(e)
                ALL_SPRITES.remove(e)

            del igrac
            del protivnik2
            del protivnik1

            smer_kretanja_X = 0
            smer_kretanja_Y = 0
            gameover_SCREEN("  YOU LOSE")

        time.sleep(0.125) #  GAME SPEED


def gameover_SCREEN(VT):
    meni = True
    global pocetak
    SCREEN.fill((135, 206, 235))
    ALL_POINTS.empty()
    ALL_WALLS.empty()
    ALL_SPRITES.empty()
    ENEMY_SPRITES.empty()
    game_over_text = veliki_tekst.render(VT, False, BLACK)
    play_again_text = mali_tekst.render("Play again", False, BLACK)
    quit_text = mali_tekst.render("Quit", False, BLACK)

    while meni:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            # if event.type == pygame.MOUSEBUTTONDOWN:

        pygame.draw.rect(SCREEN, YELLOW, (150, 75, 500, 150))  # -- NASLOV KVADRAT --
        pygame.draw.rect(SCREEN, GREEN, (300, 300, 200, 50))  # -- PLAY AGAIN KVADRAT --
        pygame.draw.rect(SCREEN, GREEN, (300, 400, 200, 50))  # -- QUIT KVADRAT --

        click = pygame.mouse.get_pressed()
        mouse = pygame.mouse.get_pos()

        if 500 > mouse[0] > 300 and 350 > mouse[1] > 300:
            pygame.draw.rect(SCREEN, RED, (300, 300, 200, 50))
            if click[0] == 1:
                meni = False
                pocetak = True
                main_loop()

        if 500 > mouse[0] > 300 and 450 > mouse[1] > 400:
            pygame.draw.rect(SCREEN, RED, (300, 400, 200, 50))
            if click[0] == 1:
                pygame.quit()
                quit()

        SCREEN.blit(game_over_text, (165, 100))
        SCREEN.blit(play_again_text, (342, 310))
        SCREEN.blit(quit_text, (372, 410))

        pygame.display.flip()
