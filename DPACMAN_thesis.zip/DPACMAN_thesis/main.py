import pygame
from settings import *
from funkcije import *



main_menu()
main_loop()


