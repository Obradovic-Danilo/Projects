import random,time

import pygame,math
from settings import *

class wall(pygame.sprite.Sprite):

    def __init__(self,x=0,y=0):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("images/zid3.jpg").convert_alpha()
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y

    def update(self):
        self.rect.x = self.x * 32
        self.rect.y = self.y * 32



class player(pygame.sprite.Sprite):

    def __init__(self,x=0,y=0):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("images/igrac.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y

    def move(self,smerA=0,smerB=0):
        global prev_loc_igraca
        prev_loc_igraca = [self.x,self.y]



        if [self.x+smerA,self.y+smerB] not in lista_zidova:
            self.x += smerA
            self.y += smerB

    def update(self):

        if self.x == -1 and self.y == 17:  # DOLE LEVO -> GORE DESNO
            self.x = 24
            self.y = 2

        elif self.x == 25 and self.y == 2:  # GORE DESNO -> DOLE LEVO
            self.x = 0
            self.y = 17

        elif self.x == -1 and self.y == 2:  # GORE LEVO -> DOLE DESNO
            self.x = 24
            self.y = 17

        elif self.x == 25 and self.y == 17:  # DOLE DESNO -> GORE LEVO
            self.x = 0
            self.y = 2
        self.rect.x = self.x * 32
        self.rect.y = self.y * 32
        self.sudar_sa_poenom()

    def sudar_sa_poenom(self):
        for p in ALL_POINTS:
            if [self.x,self.y] == [p.x,p.y]:
                ALL_SPRITES.remove(p)
                ALL_POINTS.remove(p)


    def swap_positions(self):

        global prethodne_lokacije, prev_loc_protivnika, sledeca_loc_protivnika


        #print("PRETHODNO: "+str(prev_loc_protivnika))
        #print("SLEDECE:"  +str(sledeca_loc_protivnika))

        if [self.x,self.y] in prev_loc_protivnika and prev_loc_igraca in sledeca_loc_protivnika:
            prethodne_lokacije = [[-1, 2], [-1, 17], [25, 2], [25, 17], [1, 2], [0, 2], [1, 17], [0, 17], [23, 2],
                                  [24, 2], [23, 17], [24, 17]]
            self.image.fill(LIGHTGREY)
            return True

        prev_loc_protivnika = []
        sledeca_loc_protivnika = []
        return False


    def sudar_sa_protivnikom(self):
            global prethodne_lokacije
            for e in ENEMY_SPRITES:
                if self.x == e.x and self.y == e.y or self.swap_positions():

                    prethodne_lokacije = [[-1, 2], [-1, 17], [25, 2], [25, 17], [1, 2], [0, 2], [1, 17], [0, 17],
                                          [23, 2], [24, 2], [23, 17], [24, 17]]

                    time.sleep(2)
                    return True
            prev_loc_protivnika = []
            return False



class poen(pygame.sprite.Sprite):

    def __init__(self,x=0,y=0):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("images/poen.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y

    def update(self):
        self.rect.x = self.x * 32
        self.rect.y = self.y * 32


class enemy(pygame.sprite.Sprite):



    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("images/enemy.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.target = list(random.choice(lista_bez_zidova))


    def move(self):

        global prethodne_lokacije,prev_loc_protivnika,sledeca_loc_protivnika

        prev_loc_protivnika.append([self.x,self.y])

        gore = [self.x, self.y - 1]
        dole = [self.x, self.y + 1]
        levo = [self.x - 1, self.y]
        desno = [self.x + 1, self.y]




        temp = [gore,dole,levo,desno]
        no_walls = list()
        for i in temp:
            if i not in lista_zidova and i not in prethodne_lokacije:
                no_walls.append(i)

        if len(no_walls) == 0:
            prethodne_lokacije = [[-1, 2], [-1, 17], [25, 2], [25, 17], [1, 2], [0, 2], [1, 17], [0, 17], [23, 2],
                                  [24, 2], [23, 17], [24, 17]]
            self.target = list(random.choice(lista_bez_zidova))
            for i in temp:
                if i not in lista_zidova and i not in prethodne_lokacije:
                    no_walls.append(i)

        najbliza_lokacija = [math.sqrt((self.target[0]-no_walls[0][0])**2),math.sqrt((self.target[1]-no_walls[0][1])**2)]

        prethodne_lokacije.append([self.x,self.y])

        for element in no_walls:
            dist = [math.sqrt((self.target[0]-element[0])**2),math.sqrt((self.target[1]-element[1])**2)]


            if dist[0]<=najbliza_lokacija[0] and dist[1]<=najbliza_lokacija[1]:
                najbliza_lokacija=dist
                self.x = element[0]
                self.y = element[1]

        sledeca_loc_protivnika.append([self.x,self.y])

        if self.x == self.target[0] and self.y == self.target[1]:
            self.target = list(random.choice(lista_bez_zidova))
            prethodne_lokacije = [[-1, 2], [-1, 17], [25, 2], [25, 17], [1, 2], [0, 2], [1, 17], [0, 17], [23, 2],
                                  [24, 2], [23, 17], [24, 17]]



    def update(self):
        self.rect.x = self.x * 32
        self.rect.y = self.y * 32